# Matibatidos POS — proyecto Android

Este proyecto empaqueta la interfaz web de Matibatidos POS en una aplicación Android mediante WebView.

Consulta `README_PROYECTO_DEFINITIVO.md` para el alcance de la versión 2.1.0, los cambios incorporados y los pasos de compilación.

## Puentes Android
- `AndroidPrinter`: conexión e impresión Bluetooth ESC/POS.
- `AndroidBackup`: envío de respaldos al servicio configurado.
- `AndroidFileSaver`: guardado de archivos.
- `AndroidWhatsApp`: apertura de WhatsApp con mensajes preparados.

La aplicación independiente utiliza el identificador `com.matibatidos.pos.definitiva.mejoras`; no reemplaza la versión 1.0.5.
