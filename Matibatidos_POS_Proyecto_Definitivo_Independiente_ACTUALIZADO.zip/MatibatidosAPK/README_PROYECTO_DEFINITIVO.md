# Matibatidos POS — mejoras solicitadas 2.1.0

## Esta entrega incorpora
- Punto de venta: selector opcional de mesa junto al selector de cliente; se retira la opción visible «Para llevar».
- Mesas: agregar y quitar mesas libres, mostrar el total acumulado de las cuentas ocupadas y conservar la liberación de la mesa al completar una factura.
- Inventario: filtro Desde/Hasta en el Kardex; inicialmente muestra solo los movimientos del día actual.
- Compras: filtro de fechas colocado antes de los resultados; inicialmente muestra solo las compras del día actual.
- Reportes: la vista inicial es Ventas por fechas; los turnos cerrados pasan a una pestaña independiente con filtro Desde/Hasta.
- Gastos operativos: filtro de fechas al inicio y resultados/resúmenes limitados al período seleccionado.

## Aplicación independiente
- applicationId: `com.matibatidos.pos.definitiva.mejoras`
- versionName: `2.1.0-mejoras`
- No reemplaza la aplicación original `com.matibatidos.pos` (versión 1.0.5).
- También evita intentar actualizar el APK independiente anterior con una firma debug distinta.

## Respaldo
El importador conserva la compatibilidad con el formato de respaldo externo `{app, version, createdAt, data:{state, users, activity, storage, images}}` y formatos anteriores. La restauración y las imágenes deben comprobarse en el dispositivo antes de adoptar esta APK como aplicación principal. Mantén intacto el JSON original.

## Compilación
Sube a la raíz del repositorio el ZIP `Matibatidos_POS_Proyecto_Definitivo_Independiente_ACTUALIZADO.zip` y el flujo `.github/workflows/build-apk.yml`. Ejecuta el workflow desde Actions. El artefacto esperado es `Matibatidos-POS-Mejoras-2.1.0`.

## Alcance de verificación
Esta entrega contiene el código fuente actualizado. La compilación de GitHub y las pruebas reales de mesas, facturación, filtros y restauración deben completarse en el dispositivo; no se consideran verificadas solo por editar el código.
